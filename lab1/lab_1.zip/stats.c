
Average Queue Size:
CPU = 462.589444
Disk 1 = 28.335274
Disk 2 = 28.074854
Network = 0.750000

Maximum Queue Size:
CPU = 946
Disk 1 = 58
Disk 2 = 57
Network = 2

Utilization:
CPU = 1.000000
Disk 1 = 0.999600
Disk 2 = 0.998600
Network - 0.555800

Average Response Time:
CPU = 7.530120
Disk 1 = 24.865672
Disk 2 = 24.965000
Network = 40.569343

Maximum Response Time:
CPU = 10
Disk 1 = 30
Disk 2 = 30
Network = 50

Throughput:
CPU = 0.132800
Disk 1 = 0.040200
Disk 2 = 0.040000
Network = 0.013700
